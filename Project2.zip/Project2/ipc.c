#include "ipc.h"
#include "fitness.h"
#include "map.h"
#include "chromosome.h"
#include "ga.h"
#include "header.h"
#include "chromosome.h"


/* ---------- globals ---------- */

static int g_num_workers = 0;
static pid_t g_master_pid = -1;

static pid_t *g_worker_pids = NULL;
static int   (*g_result_pipes)[2] = NULL;

static int          g_shm_id = -1;
static SharedState *g_shared = NULL;

static Map3D     *g_map_ptr = NULL;
static GA_Config *g_cfg_ptr = NULL;

/* ---------- worker ---------- */

static void worker_loop(int wid) {

    int result_fd = g_result_pipes[wid][1];

    while (1) {

        sem_wait(&g_shared->full);
        sem_wait(&g_shared->mutex);

        TaskMsg task = g_shared->buffer[g_shared->head];
        g_shared->head = (g_shared->head + 1) % QUEUE_SIZE;

        sem_post(&g_shared->mutex);
        sem_post(&g_shared->empty);

        if (task.index == -1) break;

        int idx = task.index;
        int R   = g_cfg_ptr->num_robots;

        Chromosome c;
        chromosome_alloc(&c, R);
	if (!chromosome_alloc(&c, R)) _exit(1);

        int *L = shm_lengths(g_shared);
        Vec3i *N = shm_nodes(g_shared);

        for (int r = 0; r < R; r++) {
            int len = L[idx*R + r];
            if (len < 1) len = 1;
            if (len > MAX_PATH_LEN) len = MAX_PATH_LEN;
            c.length[r] = len;

            for (int k = 0; k < len; k++) {
                c.nodes[r][k] =
                    N[(idx*R + r)*MAX_PATH_LEN + k];
            }
        }

        double fit = compute_fitness(g_map_ptr, &c, g_cfg_ptr);

        chromosome_free(&c);

        ResultMsg res = { .index = idx, .fitness = fit };
        write(result_fd, &res, sizeof(res));
    }

    close(result_fd);
    _exit(0);
}

/* ---------- init ---------- */
void ipc_init(Map3D *map, GA_Config *cfg)
{
    if (!map || !cfg) {
        fprintf(stderr, "ipc_init: invalid args\n");
        exit(1);
    }

    g_master_pid = getpid();
    g_map_ptr = map;
    g_cfg_ptr = cfg;

    g_num_workers = cfg->num_workers;
    if (g_num_workers <= 0) {
        fprintf(stderr, "ipc_init: num_workers must be > 0\n");
        exit(1);
    }

    g_worker_pids = malloc(sizeof(pid_t) * g_num_workers);
    if (!g_worker_pids) { perror("malloc g_worker_pids"); exit(1); }

    g_result_pipes = malloc(sizeof(int[2]) * g_num_workers);
    if (!g_result_pipes) { perror("malloc g_result_pipes"); exit(1); }

    int P = cfg->POP_SIZE;
    int R = cfg->num_robots;
    if (P <= 0 || R <= 0) {
        fprintf(stderr, "ipc_init: POP_SIZE and num_robots must be > 0\n");
        exit(1);
    }

    size_t len_bytes  = sizeof(int)   * (size_t)P * (size_t)R;
    size_t node_bytes = sizeof(Vec3i) * (size_t)P * (size_t)R * (size_t)MAX_PATH_LEN;
    size_t shm_size   = sizeof(SharedState) + len_bytes + node_bytes;

    key_t key = ftok("ipc_keyfile", 0x42); 
    if (key == -1) { perror("ftok"); exit(1); }

    g_shm_id = shmget(key, shm_size, IPC_CREAT | 0600);
    if (g_shm_id == -1) { perror("shmget"); exit(1); }

    g_shared = shmat(g_shm_id, NULL, 0);
    if (g_shared == (void *)-1) { perror("shmat"); exit(1); }

   
    memset(g_shared, 0, shm_size);

    g_shared->pop_size    = P;
    g_shared->num_robots  = R;
    g_shared->lengths_off = sizeof(SharedState);
    g_shared->nodes_off   = sizeof(SharedState) + len_bytes;

    if (sem_init(&g_shared->mutex, 1, 1) == -1) { perror("sem_init mutex"); exit(1); }
    if (sem_init(&g_shared->empty, 1, QUEUE_SIZE) == -1) { perror("sem_init empty"); exit(1); }
    if (sem_init(&g_shared->full,  1, 0) == -1) { perror("sem_init full"); exit(1); }

    for (int i = 0; i < g_num_workers; i++) {
        if (pipe(g_result_pipes[i]) == -1) {
            perror("pipe");
            exit(1);
        }
    }

    for (int i = 0; i < g_num_workers; i++) {
        pid_t pid = fork();
        if (pid < 0) {
            perror("fork");
            exit(1);
        }

        if (pid == 0) {
            // worker: close read ends and other workers' write ends
            for (int j = 0; j < g_num_workers; j++) {
                close(g_result_pipes[j][0]);
                if (j != i) close(g_result_pipes[j][1]);
            }
            worker_loop(i);
            _exit(0);
        }

        // master
        g_worker_pids[i] = pid;
        close(g_result_pipes[i][1]); // master doesn't write
    }

    atexit(ipc_cleanup_atexit);
    signal(SIGINT, sigint_handler);
}
/* ---------- evaluate ---------- */

void ipc_evaluate_population(Chromosome pop[], int pop_size,
                             Map3D *map, GA_Config *cfg)
{
    if (g_num_workers <= 0) {
        for (int i = 0; i < pop_size; i++)
            pop[i].fitness = compute_fitness(map, &pop[i], cfg);
        return;
    }

    int *L = shm_lengths(g_shared);
    Vec3i *N = shm_nodes(g_shared);
    int R = cfg->num_robots;

    for (int i = 0; i < pop_size; i++) {

        for (int r = 0; r < R; r++) {
            int len = pop[i].length[r];
            if (len < 1) len = 1;
            if (len > MAX_PATH_LEN) len = MAX_PATH_LEN;

            L[i*R + r] = len;

            for (int k = 0; k < len; k++)
                N[(i*R + r)*MAX_PATH_LEN + k] = pop[i].nodes[r][k];
        }

        TaskMsg t = { .index = i, .num_robots = R };

        sem_wait(&g_shared->empty);
        sem_wait(&g_shared->mutex);

        g_shared->buffer[g_shared->tail] = t;
        g_shared->tail = (g_shared->tail + 1) % QUEUE_SIZE;

        sem_post(&g_shared->mutex);
        sem_post(&g_shared->full);
    }

    int remaining = pop_size;

    while (remaining > 0) {

        fd_set fds;
        FD_ZERO(&fds);
        int maxfd = -1;

        for (int i = 0; i < g_num_workers; i++) {
            FD_SET(g_result_pipes[i][0], &fds);
            if (g_result_pipes[i][0] > maxfd)
                maxfd = g_result_pipes[i][0];
        }

        select(maxfd + 1, &fds, NULL, NULL, NULL);

        for (int i = 0; i < g_num_workers; i++) {
            if (FD_ISSET(g_result_pipes[i][0], &fds)) {
                ResultMsg res;
                if (read(g_result_pipes[i][0], &res, sizeof(res)) > 0) {
                    pop[res.index].fitness = res.fitness;
                    remaining--;
                }
            }
        }
    }
}

/* ---------- shutdown ---------- */
void ipc_enqueue_task(const TaskMsg *task)
{
    // wait for empty slot
    sem_wait(&g_shared->empty);

    // lock queue
    sem_wait(&g_shared->mutex);

    // push at tail
    g_shared->buffer[g_shared->tail] = *task;
    g_shared->tail = (g_shared->tail + 1) % QUEUE_SIZE;

    // unlock
    sem_post(&g_shared->mutex);

    // announce one full slot
    sem_post(&g_shared->full);
}
void ipc_shutdown(void)
{
    if (!g_shared) return;

    // 1) Send STOP message to each worker
    for (int i = 0; i < g_num_workers; i++) {
        TaskMsg stop;
        memset(&stop, 0, sizeof(stop));
        stop.index = -1;   // your STOP convention
        ipc_enqueue_task(&stop);
    }

    // 2) Close master pipe ends (master should read only)
    if (g_result_pipes) {
        for (int i = 0; i < g_num_workers; i++) {
            // master reads from [0]
            if (g_result_pipes[i][0] >= 0) close(g_result_pipes[i][0]);
            // master should already have closed write ends, but close defensively
            if (g_result_pipes[i][1] >= 0) close(g_result_pipes[i][1]);

            g_result_pipes[i][0] = -1;
            g_result_pipes[i][1] = -1;
        }
    }

    // 3) Wait workers to exit (VERY IMPORTANT so nattch becomes 0)
    if (g_worker_pids) {
        for (int i = 0; i < g_num_workers; i++) {
            if (g_worker_pids[i] > 0) {
                waitpid(g_worker_pids[i], NULL, 0);
                g_worker_pids[i] = -1;
            }
        }
    }

    // 4) Destroy semaphores (they live in shared memory)
    sem_destroy(&g_shared->mutex);
    sem_destroy(&g_shared->empty);
    sem_destroy(&g_shared->full);

    // 5) Detach shared memory in master
    shmdt(g_shared);
    g_shared = NULL;

    // 6) Remove shared memory segment
    if (g_shm_id != -1) {
        shmctl(g_shm_id, IPC_RMID, NULL);
        g_shm_id = -1;
    }

    // 7) Free dynamic arrays
    free(g_worker_pids);
    g_worker_pids = NULL;

    free(g_result_pipes);
    g_result_pipes = NULL;
}
void ipc_cleanup_atexit(void) {
    if (getpid() == g_master_pid)
        ipc_shutdown();
}

static volatile sig_atomic_t stopping = 0;

void sigint_handler(int sig) {
    (void)sig;
    if (stopping) _exit(1);
    stopping = 1;
    ipc_shutdown();
    _exit(1);
}
