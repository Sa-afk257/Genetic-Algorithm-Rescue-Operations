#ifndef FITNESS_H
#define FITNESS_H

#include <stdbool.h>
#include "map.h"
#include "chromosome.h"
#include "ga_config.h"

int    count_survivors_reached(Map3D *m, Chromosome *c, GA_Config *cfg);
double compute_coverage(Map3D *m, Chromosome *c, GA_Config *cfg);
int    compute_length(Chromosome *c, GA_Config *cfg);
double compute_risk(Map3D *m, Chromosome *c, GA_Config *cfg);
int    compute_collisions(Chromosome *c, GA_Config *cfg);

double compute_fitness(Map3D *m, Chromosome *c, GA_Config *cfg);

bool ***allocate_3d_bool(int X, int Y, int Z);
void    free_3d_bool(bool ***arr, int X, int Y);

#endif
