#include "path.h"
#include <stdlib.h>

// Create a new path with given capacity
Path *path_create(int capacity) {
    if (capacity <= 0) capacity = 1;

    Path *p = malloc(sizeof(Path));
    if (!p) return NULL;

    p->steps = malloc(capacity * sizeof(Vec3i));
    if (!p->steps) {
        free(p);
        return NULL;
    }

    p->length = 0;
    p->capacity = capacity;
    return p;
}

// Free memory used by a path
void path_free(Path *p) {
    if (!p) return;
    free(p->steps);
    free(p);
}

// Add one step to the end of the path
int path_push_step(Path *p, int x, int y, int z) {
    // If array is full, grow it
    if (p->length == p->capacity) {
        int new_cap = p->capacity * 2;
        Vec3i *new_steps = realloc(p->steps, new_cap * sizeof(Vec3i));
        if (!new_steps) return 0;
        p->steps = new_steps;
        p->capacity = new_cap;
    }

    p->steps[p->length].x = x;
    p->steps[p->length].y = y;
    p->steps[p->length].z = z;
    p->length++;
    return 1;
}

// Check if a path is valid:
// 1) each position inside map
// 2) each position is free (not rubble)
// 3) movement between steps is neighbor in 3D (dx,dy,dz ∈ {-1,0,1}, not all zero)
int path_is_valid(const Map3D *map, const Path *p) {
    if (!map || !p || p->length == 0) return 0;

    for (int i = 0; i < p->length; i++) {
        int x = p->steps[i].x;
        int y = p->steps[i].y;
        int z = p->steps[i].z;

        // Inside map
        if (!map_in_bounds(map, x, y, z)) return 0;

        // Free cell (empty or survivor)
        if (!map_is_free(map, x, y, z)) return 0;

        // Check neighbor movement
        if (i > 0) {
            int px = p->steps[i - 1].x;
            int py = p->steps[i - 1].y;
            int pz = p->steps[i - 1].z;

            int dx = x - px;
            int dy = y - py;
            int dz = z - pz;

            // Cannot jump more than 1 cell in any direction
            if (dx < -1 || dx > 1 ||
                dy < -1 || dy > 1 ||
                dz < -1 || dz > 1) {
                return 0;
            }

            // Cannot stay in exactly same cell
            if (dx == 0 && dy == 0 && dz == 0)
                return 0;
        }
    }

    return 1;
}

// Generate one random-walk path from start
Path *path_random_walk(const Map3D *map,
                       Vec3i start,
                       int max_len)
{
    Path *p = path_create(max_len);
    if (!p) return NULL;

    // First step = start position
    if (!path_push_step(p, start.x, start.y, start.z)) {
        path_free(p);
        return NULL;
    }

    Vec3i current = start;

    // Build the path step by step
    for (int step = 1; step < max_len; step++) {
        int found = 0;

        // Try several random neighbors
        for (int tries = 0; tries < 20 && !found; tries++) {
            int dx = (rand() % 3) - 1; // -1, 0, or 1
            int dy = (rand() % 3) - 1;
            int dz = (rand() % 3) - 1;

            if (dx == 0 && dy == 0 && dz == 0)
                continue; // no movement

            int nx = current.x + dx;
            int ny = current.y + dy;
            int nz = current.z + dz;

            if (!map_in_bounds(map, nx, ny, nz))
                continue;
            if (!map_is_free(map, nx, ny, nz))
                continue;

            // Valid neighbor → move there
            current.x = nx;
            current.y = ny;
            current.z = nz;
            path_push_step(p, nx, ny, nz);
            found = 1;
        }

        // If we cannot find any valid neighbor, stop the walk
        if (!found) {
            break;
        }
    }

    // Final safety check
    if (!path_is_valid(map, p)) {
        path_free(p);
        return NULL;
    }

    return p;
}

// Generate an array (population) of random paths
Path **population_create_random(const Map3D *map,
                                int pop_size,
                                Vec3i start,
                                int max_len)
{
    Path **pop = malloc(pop_size * sizeof(Path *));
    if (!pop) return NULL;

    for (int i = 0; i < pop_size; i++) {
        Path *path = NULL;

        // Try to build a valid path several times
        for (int tries = 0; tries < 10 && !path; tries++) {
            path = path_random_walk(map, start, max_len);
        }

        pop[i] = path; // may be NULL if all attempts failed
    }

    return pop;
}

// Free a whole population of paths
void population_free(Path **pop, int pop_size) {
    if (!pop) return;
    for (int i = 0; i < pop_size; i++) {
        if (pop[i]) path_free(pop[i]);
    }
    free(pop);
}
