#ifndef MAP_H
#define MAP_H

#include <stddef.h>

// Type of cell in the 3D grid
typedef enum {
    CELL_EMPTY    = 0,  // free space, robot can move here
    CELL_RUBBLE   = 1,  // rubble/stone, robot cannot move here
    CELL_SURVIVOR = 2   // survivor (person)
} CellType;

// Simple 3D integer vector (position in the grid)
typedef struct {
    int x, y, z;
} Vec3i;

// Information about one survivor
typedef struct {
    int id;         // index of survivor in the array
    int priority;   // rescue priority (higher = more important / more critical)
    int alive;      // 1 = alive, 0 = dead/unknown
} SurvivorInfo;

// One cell in the 3D map
typedef struct {
    CellType type;      // what is inside this cell (empty, rubble, survivor)
    int survivor_index; // index in survivors array, or -1 if no survivor
} MapCell;

// Full 3D map
typedef struct {
    int size_x, size_y, size_z;  // dimensions of the grid
    MapCell *cells;              // 1D array of size size_x * size_y * size_z

    SurvivorInfo *survivors;     // dynamic array of survivors
    int survivor_count;          // how many survivors we have now
    int survivor_capacity;       // current capacity of the array
} Map3D;

// Macro to convert (x,y,z) into index in 1D array "cells"
#define MAP_INDEX(m, x, y, z) \
    (((z) * (m)->size_y + (y)) * (m)->size_x + (x))

// Create new 3D map with given dimensions
Map3D *map_create(int sx, int sy, int sz);

// Free all memory used by the map
void   map_free(Map3D *map);

// Check if (x,y,z) is inside the map bounds
int         map_in_bounds(const Map3D *map, int x, int y, int z);

// Get pointer to cell (modifiable)
MapCell    *map_get_cell(Map3D *map, int x, int y, int z);

// Get pointer to cell (read-only)
const MapCell *map_get_cell_const(const Map3D *map, int x, int y, int z);

// True if this cell is an obstacle (rubble or outside map)
int map_is_obstacle(const Map3D *map, int x, int y, int z);

// True if this cell is free for robot (empty or survivor)
int map_is_free(const Map3D *map, int x, int y, int z);

// Set a cell to empty
void map_set_empty(Map3D *map, int x, int y, int z);

// Fill a vertical column at (x,y) with rubble from z=0 to z=height-1
void map_add_rubble_column(Map3D *map, int x, int y, int height);

// Add survivor at (x,y,z) and make sure there is support under them
// Returns survivor id, or -1 on error
int  map_add_survivor(Map3D *map, int x, int y, int z, int priority);

// Generate a rubble pyramid map with some noise and random survivors
void map_generate_pyramid(Map3D *map,
                          int max_height,
                          double rubble_noise_prob,
                          double survivor_prob);

// Get a good default entry point for the robot (from top of rubble)
Vec3i map_get_default_entry_top(const Map3D *map);

#endif // MAP_H
