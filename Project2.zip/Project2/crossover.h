#ifndef CROSSOVER_H
#define CROSSOVER_H

#include "chromosome.h"
#include "map.h"

Chromosome crossover(Chromosome *p1, Chromosome *p2, Map3D *m);

#endif
