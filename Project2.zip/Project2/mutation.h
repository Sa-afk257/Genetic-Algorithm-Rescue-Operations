#ifndef MUTATION_H
#define MUTATION_H

#include "map.h"
#include "chromosome.h"

void mutate(Chromosome *c, Map3D *m);

#endif
