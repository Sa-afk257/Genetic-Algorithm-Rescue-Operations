#include "header.h"
#include "ga_config.h"

 void SetDefaultConfig(GA_Config *cfg){
  if (!cfg)
    return;

  //IPC
  cfg -> num_workers = 4;

  // grid
  cfg -> grid_x = 20;
  cfg -> grid_y = 20;
  cfg -> grid_z = 3;
  // GA
  cfg -> POP_SIZE = 50;
  cfg -> max_generations = 100;
  cfg -> num_robots = 3;

  cfg -> w_survivors = 3.0;
  cfg -> w_coverage = 1.0;
  cfg -> w_length = 0.5;
  cfg -> w_risk = 2.0;
  cfg -> w_collision = 5.0;

  cfg -> ELITISM_RATE = 0.1;
  cfg -> TOURNAMENT_K = 2;

  cfg -> MUTATION_RATE = 0.05;
  cfg -> CROSSOVER_RATE = 0.5;

  cfg -> stagnation_limit = 25;
  cfg -> stagnation_eps   = 1e-6;
  cfg -> time_limit_sec   = 10;
}
  char *trim(char *s) {
   while (*s == ' ' || *s == '\t' || *s == '\r' || *s == '\n') s++;
   char *end = s + strlen(s);
   while (end > s && (end[-1] == ' ' || end[-1] == '\t' || end[-1] == '\r' || end[-1] == '\n'))
     *--end = '\0';
   return s;
}
 int loadConfigFile(const char *filename, GA_Config *cfg){
  
  if (!filename || !cfg)
    return -1;

  FILE *f = fopen(filename, "r");
  if (!f){
    printf(" the File Does not exist\n");
    return -1;
  }

  char line[256];

  while(fgets(line, sizeof(line), f)){
    if(line[0] == '#' || line[0] == '\n'){
       continue;
    }

       char *eq = strchr(line, '=');
       if(!eq)
	 continue;

       *eq = '\0';
       char *key = trim(line);
       char *value = trim(eq + 1);

       char *newline = strchr(value, '\n');
       if (newline)
	 *newline = '\0';

       if(strcmp(key, "GRID_X") == 0){
	 cfg -> grid_x = atoi(value);
       }else if(strcmp(key, "GRID_Y") == 0){
	 cfg -> grid_y = atoi(value);
       }else if(strcmp(key, "GRID_Z") == 0){
         cfg -> grid_z = atoi(value); 
       } else if(strcmp(key, "POP_SIZE") == 0){
	 cfg ->POP_SIZE = atoi(value);
       }else if(strcmp(key, "MAX_GENERATIONS") == 0){
	 cfg -> max_generations = atoi(value);
       }else if(strcmp(key, "NUM_WORKERS") == 0){
	 cfg -> num_workers = atoi(value);
       }else if(strcmp(key, "NUM_ROBOTS") == 0){
	 cfg -> num_robots = atoi(value);
       }else if(strcmp(key, "W_SURVIVORS") == 0){
	 cfg -> w_survivors = atof(value);
       }else if(strcmp(key, "W_COVERAGE") == 0){
	 cfg -> w_coverage = atof(value);
       }else if(strcmp(key, "W_LENGTH") == 0){
	 cfg -> w_length = atof(value);
       }else if(strcmp(key, "W_COLLISION") == 0){
	 cfg -> w_collision = atof(value);
       }else if(strcmp(key, "W_RISK") == 0){
	 cfg -> w_risk = atof(value);
       }else if(strcmp(key, "MUTATION_RATE") == 0){
	 cfg -> MUTATION_RATE = atof(value);
       }else if(strcmp(key, "CROSSOVER_RATE") == 0){
	 cfg -> CROSSOVER_RATE = atof(value);
       }else if(strcmp(key, "ELITISM_RATE") == 0){
	 cfg -> ELITISM_RATE = atof(value);
       }else if(strcmp(key, "TOURNAMENT_K") == 0){
	 cfg -> TOURNAMENT_K = atoi(value);
       }else if(strcmp(key, "stagnation_limit") == 0){
	 cfg -> stagnation_limit = atoi(value);
       }else if(strcmp(key, "stagnation_eps") == 0){
	 cfg -> stagnation_eps = atof(value);
       }else if(strcmp(key, "time_limit_sec") == 0){
	 cfg -> time_limit_sec = atoi(value);
       }
       

       
  }
    fclose(f);
    return 0;
}
void init_config(GA_Config *cfg){
  if(!cfg)
    return;
  
  SetDefaultConfig(cfg);
  
  printf("[DEBUG] After defaults: num_workers = %d\n", cfg->num_workers);
  
  if(loadConfigFile("config.txt", cfg) == 0){
    printf("Loaded Configuration from config.txt\n");
  }else{
    printf("Using Default Configuration (no config.txt)\n");
  }
  printf("[DEBUG] After config.txt: num_workers = %d\n", cfg->num_workers);
}
       
      
