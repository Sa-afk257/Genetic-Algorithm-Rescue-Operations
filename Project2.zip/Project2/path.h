#ifndef PATH_H
#define PATH_H

#include "map.h"

// One path for the robot: a sequence of 3D positions
typedef struct {
    Vec3i *steps;   // dynamic array of positions
    int length;     // how many steps used now
    int capacity;   // allocated size of the array
} Path;

// Create a new path with initial capacity
Path *path_create(int capacity);

// Free memory used by this path
void  path_free(Path *p);

// Add new step (x,y,z) at the end of path
// Returns 1 on success, 0 on error
int   path_push_step(Path *p, int x, int y, int z);

// Check if path is valid:
// - all steps inside map
// - no step in rubble
// - each step is neighbor to previous (spider movement)
int   path_is_valid(const Map3D *map, const Path *p);

// Generate one random-walk path starting from 'start'
Path *path_random_walk(const Map3D *map,
                       Vec3i start,
                       int max_len);

// Generate a population (array) of random paths
Path **population_create_random(const Map3D *map,
                                int pop_size,
                                Vec3i start,
                                int max_len);

// Free a population of paths
void   population_free(Path **pop, int pop_size);

#endif // PATH_H
