#ifndef CHROMOSOME_H
#define CHROMOSOME_H

#include <stdbool.h>
#include "map.h"   // for Vec3i

#define MAX_PATH_LEN 800

typedef struct {
    int num_robots;
    Vec3i **nodes;  // use Vec3i instead of Coord
    int *length;
    double fitness;
    bool valid;
} Chromosome;

int chromosome_alloc(Chromosome *c, int num_robots);
void chromosome_free(Chromosome *c);
void clamp_chromosome(Chromosome *c);


#endif
