#include "map.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

// Create a new map and initialize all cells to EMPTY
Map3D *map_create(int sx, int sy, int sz) {
    if (sx <= 0 || sy <= 0 || sz <= 0) return NULL;

    Map3D *m = malloc(sizeof(Map3D));
    if (!m) return NULL;

    m->size_x = sx;
    m->size_y = sy;
    m->size_z = sz;

    size_t total = (size_t)sx * sy * sz;
    m->cells = malloc(total * sizeof(MapCell));
    if (!m->cells) {
        free(m);
        return NULL;
    }

    // Initialize all cells as empty
    for (size_t i = 0; i < total; i++) {
        m->cells[i].type = CELL_EMPTY;
        m->cells[i].survivor_index = -1;
    }

    // Initialize survivors array
    m->survivor_capacity = 16;
    m->survivors = malloc(m->survivor_capacity * sizeof(SurvivorInfo));
    m->survivor_count = 0;

    return m;
}

// Free all memory used by map
void map_free(Map3D *map) {
    if (!map) return;
    free(map->cells);
    free(map->survivors);
    free(map);
}

// Check if coordinates are inside map
int map_in_bounds(const Map3D *map, int x, int y, int z) {
    return (x >= 0 && x < map->size_x &&
            y >= 0 && y < map->size_y &&
            z >= 0 && z < map->size_z);
}

// Get cell pointer (modifiable). Returns NULL if out of bounds.
MapCell *map_get_cell(Map3D *map, int x, int y, int z) {
    if (!map_in_bounds(map, x, y, z)) return NULL;
    size_t idx = MAP_INDEX(map, x, y, z);
    return &map->cells[idx];
}

// Get cell pointer (const). Returns NULL if out of bounds.
const MapCell *map_get_cell_const(const Map3D *map, int x, int y, int z) {
    if (!map_in_bounds(map, x, y, z)) return NULL;
    size_t idx = MAP_INDEX(map, x, y, z);
    return &map->cells[idx];
}

// Obstacle = rubble or outside the map
int map_is_obstacle(const Map3D *map, int x, int y, int z) {
    const MapCell *c = map_get_cell_const(map, x, y, z);
    if (!c) return 1; // outside map = obstacle
    return (c->type == CELL_RUBBLE);
}

// Free if robot can be there (empty or survivor)
int map_is_free(const Map3D *map, int x, int y, int z) {
    const MapCell *c = map_get_cell_const(map, x, y, z);
    if (!c) return 0;
    return (c->type == CELL_EMPTY || c->type == CELL_SURVIVOR);
}

// Set a cell to EMPTY
void map_set_empty(Map3D *map, int x, int y, int z) {
    MapCell *c = map_get_cell(map, x, y, z);
    if (!c) return;
    c->type = CELL_EMPTY;
    c->survivor_index = -1;
}

// Fill a whole column with rubble from z=0 to z=height-1
void map_add_rubble_column(Map3D *map, int x, int y, int height) {
    if (height > map->size_z) height = map->size_z;
    for (int z = 0; z < height; z++) {
        MapCell *c = map_get_cell(map, x, y, z);
        if (!c) continue;
        c->type = CELL_RUBBLE;
        c->survivor_index = -1;
    }
}

// Add a survivor at position (x,y,z)
// We make sure there is ground (rubble) below them
// Return survivor id, or -1 if something is wrong
int map_add_survivor(Map3D *map, int x, int y, int z, int priority) {
    if (!map_in_bounds(map, x, y, z)) return -1;
    if (z == 0) return -1; // survivor cannot be on z=0 (no cell below)

    // Cell directly under the survivor
    MapCell *below = map_get_cell(map, x, y, z - 1);
    if (!below) return -1;

    // If cell below is empty, turn it into rubble to support survivor
    if (below->type == CELL_EMPTY) {
        below->type = CELL_RUBBLE;
        below->survivor_index = -1;
    }

    // Make sure survivors array has enough capacity
    if (map->survivor_count == map->survivor_capacity) {
        int new_cap = map->survivor_capacity * 2;
        SurvivorInfo *new_arr = realloc(map->survivors,
                                        new_cap * sizeof(SurvivorInfo));
        if (!new_arr) return -1;
        map->survivors = new_arr;
        map->survivor_capacity = new_cap;
    }

    // Create survivor entry
    int id = map->survivor_count;
    map->survivors[id].id = id;
    map->survivors[id].priority = priority;
    map->survivors[id].alive = 1;

    // Mark the cell as SURVIVOR
    MapCell *cell = map_get_cell(map, x, y, z);
    cell->type = CELL_SURVIVOR;
    cell->survivor_index = id;

    map->survivor_count++;
    return id;
}

// Generate rubble pyramid and random survivors
// max_height: max rubble height in the center (top of pyramid)
// rubble_noise_prob: small chance to add extra rubble on top
// survivor_prob: chance to place a survivor in a free cell
void map_generate_pyramid(Map3D *map,
                          int max_height,
                          double rubble_noise_prob,
                          double survivor_prob)
{
    // Center of the map on x,y plane
    int cx = map->size_x / 2;
    int cy = map->size_y / 2;

    if (max_height > map->size_z)
        max_height = map->size_z;

    // 1) Build basic rubble pyramid
    for (int x = 0; x < map->size_x; x++) {
        for (int y = 0; y < map->size_y; y++) {

            int dx = abs(x - cx);
            int dy = abs(y - cy);
            int r = dx + dy; // Manhattan distance → pyramid shape

            int h = max_height - r;
            if (h < 0) h = 0;

            // Basic rubble column
            map_add_rubble_column(map, x, y, h);

            // Above the basic rubble, we may add some extra noise rubble
            for (int z = h; z < map->size_z; z++) {
                MapCell *c = map_get_cell(map, x, y, z);
                if (!c) continue;
                c->type = CELL_EMPTY;
                c->survivor_index = -1;

                double rnd = (double)rand() / RAND_MAX;
                if (rnd < rubble_noise_prob) {
                    c->type = CELL_RUBBLE;
                    c->survivor_index = -1;

                    // Make sure rubble is not floating in air:
                    // if below is empty, turn it to rubble too
                    if (z > 0) {
                        MapCell *below = map_get_cell(map, x, y, z - 1);
                        if (below && below->type == CELL_EMPTY) {
                            below->type = CELL_RUBBLE;
                            below->survivor_index = -1;
                        }
                    }
                }
            }
        }
    }

    // 2) Place survivors in some empty cells (not at z=0)
    for (int x = 0; x < map->size_x; x++) {
        for (int y = 0; y < map->size_y; y++) {
            for (int z = 1; z < map->size_z; z++) { // start from z=1
                MapCell *c = map_get_cell(map, x, y, z);
                if (!c) continue;
                if (c->type != CELL_EMPTY) continue;

                double rnd = (double)rand() / RAND_MAX;
                if (rnd < survivor_prob) {
                    // Priority between 50 and 100
                    int priority = 50 + rand() % 51;
                    map_add_survivor(map, x, y, z, priority);
                }
            }
        }
    }
}

// Choose an entry point for the robot from the top of the rubble
// We start from center (x,y) at top z and go down until we find a free cell
Vec3i map_get_default_entry_top(const Map3D *map) {
    Vec3i entry = { map->size_x / 2, map->size_y / 2, map->size_z - 1 };

    // Go down on z until we find a free cell
    for (int z = map->size_z - 1; z >= 0; z--) {
        if (map_is_free(map, entry.x, entry.y, z)) {
            entry.z = z;
            return entry;
        }
    }

    // If no free cell found (very unlikely), return (center, 0)
    entry.z = 0;
    return entry;
}
