#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#include "fitness.h"
#include "map.h"
#include "chromosome.h"
#include "ga.h"
#include "ga_config.h"


/* ============================================================
   COUNT SURVIVORS REACHED
   ------------------------------------------------------------
   Counts how many *unique* survivor cells this path visited.
   ============================================================ */
int count_survivors_reached(Map3D *m, Chromosome *c, GA_Config *cfg) {
    bool ***visited = allocate_3d_bool(m->size_x, m->size_y, m->size_z);
    int count = 0;

    int R = cfg->num_robots;
    for (int r = 0; r < R; r++) {
        for (int i = 0; i < c->length[r]; i++) {
            int x = c->nodes[r][i].x;
            int y = c->nodes[r][i].y;
            int z = c->nodes[r][i].z;

            if (!map_in_bounds(m, x, y, z)) continue;

            const MapCell *cell = map_get_cell_const(m, x, y, z);
            if (!cell) continue;

            if (cell->type == CELL_SURVIVOR && !visited[x][y][z]) {
                visited[x][y][z] = true;

                int sid = cell->survivor_index;
                if (sid >= 0 && sid < m->survivor_count)
                    count += m->survivors[sid].priority;
                else
                    count += 1;
            }
        }
    }

    free_3d_bool(visited, m->size_x, m->size_y);
    return count;
}

/* ============================================================
   COMPUTE COVERAGE
   ------------------------------------------------------------
   Count unique free cells visited by the path.
   Coverage = visited_free / total_free_cells.
   ============================================================ */
double compute_coverage(Map3D *m, Chromosome *c, GA_Config *cfg) {
    bool ***visited = allocate_3d_bool(m->size_x, m->size_y, m->size_z);
    int visited_count = 0;

    int R = cfg->num_robots;
    for (int r = 0; r < R; r++) {
        for (int i = 0; i < c->length[r]; i++) {
            int x = c->nodes[r][i].x;
            int y = c->nodes[r][i].y;
            int z = c->nodes[r][i].z;

            if (!map_in_bounds(m, x, y, z)) continue;
            if (!map_is_free(m, x, y, z)) continue;

            if (!visited[x][y][z]) {
                visited[x][y][z] = true;
                visited_count++;
            }
        }
    }

    int total_free = 0;
    for (int x = 0; x < m->size_x; x++)
        for (int y = 0; y < m->size_y; y++)
            for (int z = 0; z < m->size_z; z++)
                if (map_is_free(m, x, y, z)) total_free++;

    free_3d_bool(visited, m->size_x, m->size_y);

    if (total_free == 0) return 0.0;
    return (double)visited_count / (double)total_free;
}

/* ============================================================
   COMPUTE LENGTH
   ------------------------------------------------------------
   Returns chromosome length directly.
   ============================================================ */
int compute_length(Chromosome *c, GA_Config *cfg) {
    int sum = 0;
    for (int r = 0; r < cfg->num_robots; r++) {
        sum += c->length[r];
    }
    return sum;
}

/* ============================================================
   COMPUTE RISK
   ------------------------------------------------------------
   Counts adjacent obstacles for each node.
   Risk is normalized to 0..1
   ============================================================ */
double compute_risk(Map3D *m, Chromosome *c, GA_Config *cfg) {
    int risk_count = 0;

    int R = cfg->num_robots;
    for (int r = 0; r < R; r++) {
        for (int i = 0; i < c->length[r]; i++) {
            int x = c->nodes[r][i].x;
            int y = c->nodes[r][i].y;
            int z = c->nodes[r][i].z;

            for (int dx = -1; dx <= 1; dx++)
            for (int dy = -1; dy <= 1; dy++)
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dy == 0 && dz == 0) continue;

                int nx = x + dx, ny = y + dy, nz = z + dz;
                if (map_in_bounds(m, nx, ny, nz) && map_is_obstacle(m, nx, ny, nz))
                    risk_count++;
            }
        }
    }

    int total_steps = compute_length(c, cfg);
    double max_risk = (double)total_steps * 26.0;
    if (max_risk == 0.0) return 0.0;

    return (double)risk_count / max_risk;
}
/* ============================================================
   COMPUTE COLLISION
   -------------------------------------------------------------*/
 static int same_pos(Vec3i a, Vec3i b) {
    return (a.x == b.x && a.y == b.y && a.z == b.z);
}

int compute_collisions(Chromosome *c, GA_Config *cfg) {
    int R = cfg->num_robots;
    if (R < 2) return 0;

    int T = 0;
    for (int r = 0; r < R; r++)
        if (c->length[r] > T) T = c->length[r];

    if (T <= 1) return 0;

    int collisions = 0;

    for (int t = 0; t < T; t++) {
        for (int a = 0; a < R; a++) {
            Vec3i A = c->nodes[a][ (t < c->length[a]) ? t : (c->length[a]-1) ];

            for (int b = a + 1; b < R; b++) {
                Vec3i B = c->nodes[b][ (t < c->length[b]) ? t : (c->length[b]-1) ];

                if (same_pos(A, B)) collisions++;

                if (t > 0) {
                    Vec3i Aprev = c->nodes[a][ (t-1 < c->length[a]) ? (t-1) : (c->length[a]-1) ];
                    Vec3i Bprev = c->nodes[b][ (t-1 < c->length[b]) ? (t-1) : (c->length[b]-1) ];
                    if (same_pos(Aprev, B) && same_pos(Bprev, A)) collisions++;
                }
            }
        }
    }

    return collisions;
}

/* ============================================================
   COMPUTE FITNESS (FINAL FORMULA)
   ------------------------------------------------------------
   Uses:
     - survivors reached
     - coverage
     - length (normalized)
     - risk  (normalized)
   ============================================================ */
double compute_fitness(Map3D *m, Chromosome *c, GA_Config *cfg) {
    int survivors = count_survivors_reached(m, c, cfg);
    double cov    = compute_coverage(m, c, cfg);
    double len    = (double)compute_length(c, cfg);
    double risk   = compute_risk(m, c, cfg);
    int col       = compute_collisions(c, cfg);

    double len_norm = len / (double)MAX_PATH_LEN;

    double fitness =
          cfg->w_survivors * (double)survivors
        + cfg->w_coverage  * cov
        - cfg->w_length    * len_norm
        - cfg->w_risk      * risk
        - cfg->w_collision * (double)col;

    return fitness;
}
/* ============================================================
   Utility helpers for 3D boolean arrays
   ============================================================ */
bool ***allocate_3d_bool(int X, int Y, int Z) {

    bool ***arr = malloc(X * sizeof(bool **));
    for (int x = 0; x < X; x++) {
        arr[x] = malloc(Y * sizeof(bool *));
        for (int y = 0; y < Y; y++) {
            arr[x][y] = malloc(Z * sizeof(bool));
            memset(arr[x][y], 0, Z * sizeof(bool));
        }
    }
    return arr;
}

void free_3d_bool(bool ***arr, int X, int Y) {
    for (int x = 0; x < X; x++) {
        for (int y = 0; y < Y; y++) {
            free(arr[x][y]);
        }
        free(arr[x]);
    }
    free(arr);
}
