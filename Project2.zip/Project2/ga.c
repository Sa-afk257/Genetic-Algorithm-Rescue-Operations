
#include "ga.h"
#include "map.h"         // using Map3D + Vec3i
#include "chromosome.h"
#include "fitness.h"
#include "mutation.h"
#include "crossover.h"
#include "ipc.h"
#include "astar.h"
#include "header.h"

//--------------------------------------------------------------
// Helpers for path repair
//--------------------------------------------------------------

 int MOVES26[26][3];
 int MOVES26_INIT = 0;

 void init_moves26(void) {
    if (MOVES26_INIT) return;
    int idx = 0;
    for (int dx = -1; dx <= 1; dx++) {
        for (int dy = -1; dy <= 1; dy++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dy == 0 && dz == 0) continue;
                MOVES26[idx][0] = dx;
                MOVES26[idx][1] = dy;
                MOVES26[idx][2] = dz;
                idx++;
            }
        }
    }
    MOVES26_INIT = 1; // idx should be 26
}

static int is_spider_move(Vec3i a, Vec3i b) {
    int dx = abs(a.x - b.x);
    int dy = abs(a.y - b.y);
    int dz = abs(a.z - b.z);
    return (dx <= 1 && dy <= 1 && dz <= 1 && (dx + dy + dz) > 0);
}

 int rnd(int n) {
    return rand() % n;
}

Vec3i map_get_random_survivor_or_free(Map3D *map) {
    while (1) {
        int x = rand() % map->size_x;
        int y = rand() % map->size_y;
        int z = rand() % map->size_z;

        if (map_is_free(map, x, y, z))
            return (Vec3i){x,y,z};
    }
}

void init_population(Map3D *map, GA_Config *cfg, Chromosome pop[]) {

    Vec3i entry = map_get_default_entry_top(map);

    for (int i = 0; i < cfg->POP_SIZE; i++) {
        Chromosome *c = &pop[i];

        // chromosome_alloc already set num_robots and allocated nodes/length
        c->fitness = 0.0;
        c->valid   = true;

        for (int r = 0; r < c->num_robots; r++) {

            Vec3i goal = map_get_random_survivor_or_free(map);

            int len = astar_find_path(
                map,
                entry,
                goal,
                c->nodes[r],       
                MAX_PATH_LEN
            );

            if (len <= 0) {
                c->nodes[r][0] = entry;
                c->length[r] = 1;
            } else {
	      if (len > MAX_PATH_LEN)
		len = MAX_PATH_LEN;
              c->length[r] = len;
            }
        }
    }
}

/* Move one step toward target */
 Vec3i step_toward(Vec3i from, Vec3i to) {
    Vec3i n = from;

    if (to.x > from.x) n.x++;
    else if (to.x < from.x) n.x--;

    if (to.y > from.y) n.y++;
    else if (to.y < from.y) n.y--;

    if (to.z > from.z) n.z++;
    else if (to.z < from.z) n.z--;

    return n;
}

 static int same_pos(Vec3i a, Vec3i b) {
    return a.x==b.x && a.y==b.y && a.z==b.z;
}

void repair_one_path(Vec3i *nodes, int *len, Map3D *m) {
    if (!nodes || !len || !m) return;
    if (*len < 1) return;

    Vec3i repaired[MAX_PATH_LEN];
    int out = 0;

    // always keep first node
    repaired[out++] = nodes[0];

    for (int i = 1; i < *len && out < MAX_PATH_LEN; i++) {

        Vec3i last   = repaired[out - 1];
        Vec3i target = nodes[i];

        // 1) remove duplicates
        if (same_pos(last, target)) continue;

        // 2) if neighbor, keep it
        if (is_spider_move(last, target)) {
            repaired[out++] = target;
            continue;
        }

        // 3) not neighbor => bridge with A*
        Vec3i tmp[MAX_PATH_LEN];
        int remaining = MAX_PATH_LEN - out;
        if (remaining <= 0) break;

        int sublen = astar_find_path(m, last, target, tmp, remaining);

        if (sublen <= 0) {
            // can't repair this jump => stop here so we don't keep an invalid move
            break;
        }

        // tmp[0] == last, so append from tmp[1..]
        for (int k = 1; k < sublen && out < MAX_PATH_LEN; k++) {
            // extra safety: avoid accidental duplicates
            if (!same_pos(repaired[out - 1], tmp[k]))
                repaired[out++] = tmp[k];
        }
    }

    // write back
    memcpy(nodes, repaired, out * sizeof(Vec3i));
    *len = out;

    // final safety clamp
    if (*len < 1) *len = 1;
    if (*len > MAX_PATH_LEN) *len = MAX_PATH_LEN;
}
void repair_path(Chromosome *c, Map3D *m) {
    for (int r = 0; r < c->num_robots; r++) {
        repair_one_path(c->nodes[r], &c->length[r], m);
    }
}

void mutate(Chromosome *c, Map3D *m) {
    init_moves26();

    if (c->num_robots < 1) return;

    int rbot = rand() % c->num_robots;   // choose which robot to mutate
    Vec3i *path = c->nodes[rbot];
    int   *len  = &c->length[rbot];

    if (*len < 1) return;

    int choice = rand() % 4;

    // --- apply mutation on selected robot path only ---
    if (choice == 0) { // change direction
       int idx = ( *len > 1 ) ? (1 + rand() % (*len - 1)) : 0;
        Vec3i base = path[idx];
        Vec3i newp = base;
        int mv = rand() % 26;
        newp.x += MOVES26[mv][0];
        newp.y += MOVES26[mv][1];
        newp.z += MOVES26[mv][2];
        if (map_in_bounds(m, newp.x, newp.y, newp.z) && map_is_free(m, newp.x, newp.y, newp.z))
            path[idx] = newp;

    } else if (choice == 1) { // insert
        if (*len >= MAX_PATH_LEN - 1) return;
        int idx = rand() % (*len);
        Vec3i base = path[idx];
        Vec3i newp = base;
        int mv = rand() % 26;
        newp.x += MOVES26[mv][0];
        newp.y += MOVES26[mv][1];
        newp.z += MOVES26[mv][2];
        if (!map_in_bounds(m, newp.x, newp.y, newp.z)) return;
        if (!map_is_free(m, newp.x, newp.y, newp.z)) return;

        for (int i = *len; i > idx + 1; i--) path[i] = path[i-1];
        path[idx+1] = newp;
        (*len)++;

    } else if (choice == 2) { // delete
        if (*len <= 2) return;
        int idx = rand() % (*len);
        for (int i = idx; i < (*len) - 1; i++) path[i] = path[i+1];
        (*len)--;

    } else { // avoid obstacle
        int idx = rand() % (*len);
        Vec3i base = path[idx];
        for (int mv = 0; mv < 26; mv++) {
            int nx = base.x + MOVES26[mv][0];
            int ny = base.y + MOVES26[mv][1];
            int nz = base.z + MOVES26[mv][2];
            if (map_in_bounds(m, nx, ny, nz) && map_is_free(m, nx, ny, nz)) {
                path[idx] = (Vec3i){nx, ny, nz};
                break;
            }
        }
    }

    // repair after mutation
    repair_one_path(path, len, m);
}

 void chromosome_copy_into(Chromosome *dst, const Chromosome *src) {
    dst->num_robots = src->num_robots;
    dst->valid      = src->valid;
    dst->fitness    = src->fitness;

    for (int r = 0; r < src->num_robots; r++) {
        int len = src->length[r];
        if (len < 0) len = 0;
        if (len > MAX_PATH_LEN) len = MAX_PATH_LEN;

        dst->length[r] = len;
        memcpy(dst->nodes[r], src->nodes[r], sizeof(Vec3i) * len);
    }
}

//--------------------------------------------------------------
// Tournament selection
//--------------------------------------------------------------
int tournament_selection(Chromosome pop[], int pop_size, int k) {
    int best = rand() % pop_size;

    for (int i = 1; i < k; i++) {
        int r = rand() % pop_size;
        if (pop[r].fitness > pop[best].fitness)
            best = r;
    }
    return best;
}

//--------------------------------------------------------------
// Compare fitness
//--------------------------------------------------------------
int compare_chromosomes(const void *a, const void *b) {
    const Chromosome *c1 = a;
    const Chromosome *c2 = b;

    if (c1->fitness < c2->fitness) return 1;
    if (c1->fitness > c2->fitness) return -1;
    return 0;
}



//--------------------------------------------------------------
// Produce next generation
//--------------------------------------------------------------
 void crossover_into(Chromosome *dst, const Chromosome *p1, const Chromosome *p2, Map3D *m) {
    dst->num_robots = p1->num_robots;
    dst->valid = true;
    dst->fitness = 0.0;

    for (int r = 0; r < p1->num_robots; r++) {
        int L1 = p1->length[r];
        int L2 = p2->length[r];

        // fallback: copy p1 path
        if (L1 < 2 || L2 < 2) {
            dst->length[r] = L1;
            memcpy(dst->nodes[r], p1->nodes[r], sizeof(Vec3i) * L1);
            continue;
        }

        int cut1 = rand() % L1;
        int cut2 = rand() % L2;

        int out = 0;
        for (int i = 0; i <= cut1 && out < MAX_PATH_LEN; i++)
            dst->nodes[r][out++] = p1->nodes[r][i];

        for (int j = cut2; j < L2 && out < MAX_PATH_LEN; j++)
            dst->nodes[r][out++] = p2->nodes[r][j];

        if (out < 1) {
            dst->nodes[r][0] = p1->nodes[r][0];
            out = 1;
        }
        dst->length[r] = out;

        // repair only this robot path
        repair_one_path(dst->nodes[r], &dst->length[r], m);
    }
    clamp_chromosome(dst);
}
void produce_next_generation(Map3D *m, Chromosome pop[],
                             Chromosome new_pop[], GA_Config *cfg)
{
    qsort(pop, cfg->POP_SIZE, sizeof(Chromosome), compare_chromosomes);

    int elite_count = (int)(cfg->ELITISM_RATE * cfg->POP_SIZE);
    if (elite_count < 1) elite_count = 1;

    // --- Elitism: deep copy the best chromosomes into new_pop ---
    for (int i = 0; i < elite_count; i++) {
        chromosome_copy_into(&new_pop[i], &pop[i]);
    }

    // --- Generate the rest ---
    for (int i = elite_count; i < cfg->POP_SIZE; i++) {

        int p1_i = tournament_selection(pop, cfg->POP_SIZE, cfg->TOURNAMENT_K);
        int p2_i = tournament_selection(pop, cfg->POP_SIZE, cfg->TOURNAMENT_K);

        Chromosome *p1 = &pop[p1_i];
        Chromosome *p2 = &pop[p2_i];
        Chromosome *child = &new_pop[i];   // ✅ write directly into allocated slot

        // Either crossover or copy parent 1
        if ((double)rand() / RAND_MAX < cfg->CROSSOVER_RATE) {
            crossover_into(child, p1, p2, m);
        } else {
            chromosome_copy_into(child, p1);
        }

        // Mutation (mutate chooses random robot internally)
        if ((double)rand() / RAND_MAX < cfg->MUTATION_RATE) {
            mutate(child, m);
            repair_path(child, m); // repairs all robots (or keep mutate's repair)
	    clamp_chromosome(child);
        }

        child->fitness = 0.0;  // IPC will compute later
        child->valid   = true;
    }
}

void print_best_path(const Chromosome *c) {
    for (int r = 0; r < c->num_robots; r++) {
      int L = c->length[r];
      if (L > MAX_PATH_LEN) L = MAX_PATH_LEN;
        printf("Robot %d Path (len=%d):\n", r, c->length[r]);
        for (int k = 0; k < L; k++) {
            printf("  (%d,%d,%d)\n",
                   c->nodes[r][k].x, c->nodes[r][k].y, c->nodes[r][k].z);
        }
    }
}
 int is_neighbor26(Vec3i a, Vec3i b) {
    int dx = abs(a.x - b.x), dy = abs(a.y - b.y), dz = abs(a.z - b.z);
    if (dx == 0 && dy == 0 && dz == 0) return 0;     // no "wait" (change to 1 if you allow waiting)
    return (dx <= 1 && dy <= 1 && dz <= 1);
}

 void print_path_with_survivors(const Map3D *m, const Chromosome *c) {

   int global_survivor_count = 0;
   
    if (!m || !c) return;

    // track unique survivors reached by all robots
    unsigned char *global_seen = calloc((size_t)m->survivor_count, 1);
    int global_total_priority = 0;

    for (int r = 0; r < c->num_robots; r++) {
        int L = c->length[r];
        if (L > MAX_PATH_LEN) L = MAX_PATH_LEN;

        printf("Robot %d Path (len=%d):\n", r, L);

        // track unique survivors reached by this robot
        unsigned char *robot_seen = calloc((size_t)m->survivor_count, 1);
        int robot_total_priority = 0;

        for (int k = 0; k < L; k++) {
            Vec3i p = c->nodes[r][k];
            printf("  (%d,%d,%d)\n", p.x, p.y, p.z);

            // validate deployable move (optional but recommended)
            if (k > 0) {
                Vec3i prev = c->nodes[r][k-1];
                if (!is_neighbor26(prev, p)) {
                    printf("  [WARNING] NOT DEPLOYABLE MOVE at step %d: (%d,%d,%d)->(%d,%d,%d)\n",
                           k, prev.x, prev.y, prev.z, p.x, p.y, p.z);
                }
            }

            // survivor detection
            if (!map_in_bounds(m, p.x, p.y, p.z)) continue;
            const MapCell *cell = map_get_cell_const(m, p.x, p.y, p.z);
            if (!cell) continue;

            if (cell->type == CELL_SURVIVOR) {
                int sid = cell->survivor_index;
                if (sid >= 0 && sid < m->survivor_count) {
                    if (!robot_seen[sid]) {
                        robot_seen[sid] = 1;
                        int pri = m->survivors[sid].priority;
                        robot_total_priority += pri;
                        printf("    -> Reached SURVIVOR id=%d priority=%d at (%d,%d,%d)\n",
                               sid, pri, p.x, p.y, p.z);
                    }
                    if (!global_seen[sid]) {
                        global_seen[sid] = 1;
			global_survivor_count++;
                        global_total_priority += m->survivors[sid].priority;
                    }
                }
            }
        }

        printf("Robot %d total reached priority = %d\n\n", r, robot_total_priority);
        free(robot_seen);
    }

    printf("TOTAL unique survivors reached by ALL robots = %d\n",
	   global_survivor_count);
    printf("TOTAL rescue priority achieved by ALL robots = %d\n",
	   global_total_priority);
    free(global_seen);
}

void run_ga(Map3D *m, GA_Config *cfg, Chromosome pop[]) {

    init_moves26();

    Chromosome *new_pop = malloc(sizeof(Chromosome) * cfg->POP_SIZE);
    if (!new_pop) { perror("malloc new_pop"); exit(1); }

    // allocate dynamic buffers for new_pop
    for (int i = 0; i < cfg->POP_SIZE; i++) {
        if (!chromosome_alloc(&new_pop[i], cfg->num_robots)) {
            fprintf(stderr, "Failed to alloc new_pop[%d]\n", i);
            exit(1);
        }
    }
    
	 
    ipc_evaluate_population(pop, cfg->POP_SIZE, m, cfg);
    qsort(pop, cfg->POP_SIZE, sizeof(Chromosome), compare_chromosomes);


    // ---- stopping conditions state ----
	 double best_seen = pop[0].fitness;   // will update after first sort
	  int stagnant = 0;
	 time_t t0 = time(NULL);
     printf("Gen 0 | Best fitness = %.4f\n",  pop[0].fitness);
     fflush(stdout);
     
    for (int gen = 1; gen < cfg->max_generations; gen++) {

        qsort(pop, cfg->POP_SIZE, sizeof(Chromosome), compare_chromosomes);

        Chromosome *best = &pop[0];
        printf("Gen %d | Best fitness = %.4f\n", gen, best->fitness);

	// ---- Stagnation stop ----
	if (best->fitness > best_seen + cfg->stagnation_eps) {
	  best_seen = best->fitness;
	  stagnant = 0;
	} else {
	  stagnant++;
	}

	if (cfg->stagnation_limit > 0 && stagnant >= cfg->stagnation_limit) {
	  printf("[STOP] Stagnation: no improvement for %d generations\n", cfg->stagnation_limit);
	  break;
	}

	// ---- Time stop ----
	if (cfg->time_limit_sec > 0) {
	  int elapsed = (int)(time(NULL) - t0);
	  if (elapsed >= cfg->time_limit_sec) {
	    printf("[STOP] Time limit reached: %d seconds\n", cfg->time_limit_sec);
	    break;
	  }
	}

        produce_next_generation(m, pop, new_pop, cfg);

        // deep-copy new_pop -> pop (NO memcpy)
        for (int i = 0; i < cfg->POP_SIZE; i++) {
            chromosome_copy_into(&pop[i], &new_pop[i]);
        }

        ipc_evaluate_population(pop, cfg->POP_SIZE, m, cfg);
    }

    qsort(pop, cfg->POP_SIZE, sizeof(Chromosome), compare_chromosomes);
    printf("\nFinal Best Fitness = %.4f\n", pop[0].fitness);
    //print_best_path(&pop[0]);
    print_path_with_survivors(m, &pop[0]);

    for (int i = 0; i < cfg->POP_SIZE; i++) chromosome_free(&new_pop[i]);
    free(new_pop);
}
