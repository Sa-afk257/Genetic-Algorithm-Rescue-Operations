#ifndef IPC_H
#define IPC_H

#include <semaphore.h>
#include <sys/types.h>
#include <stdbool.h>
#include "map.h"
#include "ga_config.h"
#include "chromosome.h"

#define QUEUE_SIZE 64

/* ---------- Task / Result messages ---------- */

typedef struct {
    int index;        // chromosome index
    int num_robots;
} TaskMsg;

typedef struct {
    int index;
    double fitness;
} ResultMsg;

/* ---------- Shared State (ALL inside shm) ---------- */

typedef struct {
    sem_t mutex;
    sem_t empty;
    sem_t full;

    int head;
    int tail;

    TaskMsg buffer[QUEUE_SIZE];

    int pop_size;        // P
    int num_robots;      // R

    size_t lengths_off;  // offset in shm
    size_t nodes_off;    // offset in shm
} SharedState;

/* ---------- helpers ---------- */
static inline int* shm_lengths(SharedState *s) {
    return (int*)((char*)s + s->lengths_off);
}

static inline Vec3i* shm_nodes(SharedState *s) {
    return (Vec3i*)((char*)s + s->nodes_off);
}

/* ---------- API ---------- */

void ipc_init(Map3D *map, GA_Config *cfg);
void ipc_shutdown(void);
void ipc_cleanup_atexit(void);
void sigint_handler(int sig);

void ipc_evaluate_population(Chromosome pop[], int pop_size,
                             Map3D *map, GA_Config *cfg);

#endif
