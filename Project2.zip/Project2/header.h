#ifndef __HEADER_H_
#define __HEADER_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>    
#include <sys/types.h>
#include <sys/wait.h>  
#include <signal.h>    
#include <sys/ipc.h>
#include <sys/shm.h>
#include <semaphore.h>
#include <sys/select.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>




#endif


