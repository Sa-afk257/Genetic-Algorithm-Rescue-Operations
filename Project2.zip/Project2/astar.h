#ifndef ASTAR_H
#define ASTAR_H

#include "map.h"
#include "chromosome.h"

int astar_find_path(
    Map3D *map,
    Vec3i start,
    Vec3i goal,
    Vec3i out_path[],
    int max_len
);

#endif
