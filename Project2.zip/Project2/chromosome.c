#include <stdlib.h>
#include <string.h>
#include "chromosome.h"

int chromosome_alloc(Chromosome *c, int num_robots) {
    if (!c || num_robots < 1) return 0;

    memset(c, 0, sizeof(*c));
    c->num_robots = num_robots;

    c->length = malloc(sizeof(int) * num_robots);
    if (!c->length) return 0;

    c->nodes = malloc(sizeof(Vec3i*) * num_robots);
    if (!c->nodes) {
        free(c->length);
        return 0;
    }

    for (int r = 0; r < num_robots; r++) {
        c->nodes[r] = malloc(sizeof(Vec3i) * MAX_PATH_LEN);
        if (!c->nodes[r]) {
            for (int j = 0; j < r; j++) free(c->nodes[j]);
            free(c->nodes);
            free(c->length);
            return 0;
        }
        c->length[r] = 0;
    }

    c->fitness = 0.0;
    c->valid = true;
    return 1;
}

void chromosome_free(Chromosome *c) {
    if (!c) return;
    if (c->nodes) {
        for (int r = 0; r < c->num_robots; r++) {
            free(c->nodes[r]);
        }
        free(c->nodes);
    }
    free(c->length);

    c->nodes = NULL;
    c->length = NULL;
    c->num_robots = 0;
}
void clamp_chromosome(Chromosome *c) {
    for (int r = 0; r < c->num_robots; r++) {
        if (c->length[r] > MAX_PATH_LEN) {
            c->length[r] = MAX_PATH_LEN;
        }
        if (c->length[r] < 1) {
            c->length[r] = 1;
        }
    }
}
