#include <stdlib.h>
#include <string.h>
#include <math.h>   // if you use abs, or include stdlib.h already
#include "header.h"
#include "astar.h"

typedef struct {
    Vec3i pos;
    float g, f;
    int parent;
} Node;

static float heuristic(Vec3i a, Vec3i b) {
    return (float)(abs(a.x - b.x) + abs(a.y - b.y) + abs(a.z - b.z));
}

int astar_find_path(Map3D *map, Vec3i start, Vec3i goal,
                    Vec3i out_path[], int max_len)
{
    if (!map || max_len <= 0) return 0;

    int X = map->size_x, Y = map->size_y, Z = map->size_z;
    if (X <= 0 || Y <= 0 || Z <= 0) return 0;

    // 1D index helper
    #define IDX(x,y,z) ((size_t)(x)*(size_t)Y*(size_t)Z + (size_t)(y)*(size_t)Z + (size_t)(z))

    size_t grid_sz = (size_t)X * (size_t)Y * (size_t)Z;

    // closed/seen on heap (avoid huge stack VLA)
    unsigned char *closed = (unsigned char*)calloc(grid_sz, 1);
    unsigned char *seen   = (unsigned char*)calloc(grid_sz, 1);
    if (!closed || !seen) {
        free(closed); free(seen);
        return 0;
    }

    // dynamic arrays
    size_t nodes_cap = 4096;
    size_t open_cap  = 4096;

    Node *nodes = (Node*)malloc(nodes_cap * sizeof(Node));
    int  *open  = (int*) malloc(open_cap  * sizeof(int));
    if (!nodes || !open) {
        free(nodes); free(open);
        free(closed); free(seen);
        return 0;
    }

    int node_count = 0;
    int open_count = 0;

    // push start
    nodes[0] = (Node){ start, 0.0f, heuristic(start, goal), -1 };
    open[open_count++] = 0;
    node_count = 1;
    seen[IDX(start.x, start.y, start.z)] = 1;

    while (open_count > 0) {

        // find lowest f in open
        int best_i = 0;
        for (int i = 1; i < open_count; i++) {
            if (nodes[open[i]].f < nodes[open[best_i]].f)
                best_i = i;
        }

        int cur_idx = open[best_i];
        Node cur = nodes[cur_idx];

        // pop best
        open[best_i] = open[--open_count];

        // goal check
        if (cur.pos.x == goal.x && cur.pos.y == goal.y && cur.pos.z == goal.z) {

            int len = 0;
            while (cur_idx != -1 && len < max_len) {
                out_path[len++] = nodes[cur_idx].pos;
                cur_idx = nodes[cur_idx].parent;
            }

            // reverse
            for (int i = 0; i < len/2; i++) {
                Vec3i tmp = out_path[i];
                out_path[i] = out_path[len-1-i];
                out_path[len-1-i] = tmp;
            }

            free(nodes); free(open);
            free(closed); free(seen);
            return len;
        }

        closed[IDX(cur.pos.x, cur.pos.y, cur.pos.z)] = 1;

        for (int dx = -1; dx <= 1; dx++)
        for (int dy = -1; dy <= 1; dy++)
        for (int dz = -1; dz <= 1; dz++) {

            if (dx==0 && dy==0 && dz==0) continue;

            Vec3i n = { cur.pos.x+dx, cur.pos.y+dy, cur.pos.z+dz };

            if (!map_in_bounds(map, n.x, n.y, n.z)) continue;
            if (!map_is_free(map, n.x, n.y, n.z)) continue;

            size_t id = IDX(n.x, n.y, n.z);
            if (closed[id]) continue;
            if (seen[id])   continue;   // prevents duplicates/explosion

            // grow nodes if needed
            if ((size_t)node_count >= nodes_cap) {
                size_t new_cap = nodes_cap * 2;
                Node *tmp = (Node*)realloc(nodes, new_cap * sizeof(Node));
                if (!tmp) { // out of memory
                    free(nodes); free(open);
                    free(closed); free(seen);
                    return 0;
                }
                nodes = tmp;
                nodes_cap = new_cap;
            }

            // grow open if needed
            if ((size_t)open_count >= open_cap) {
                size_t new_cap = open_cap * 2;
                int *tmp = (int*)realloc(open, new_cap * sizeof(int));
                if (!tmp) {
                    free(nodes); free(open);
                    free(closed); free(seen);
                    return 0;
                }
                open = tmp;
                open_cap = new_cap;
            }

            float ng = cur.g + 1.0f;
            nodes[node_count] = (Node){
                n,
                ng,
                ng + heuristic(n, goal),
                cur_idx
            };

            open[open_count++] = node_count;
            seen[id] = 1;
            node_count++;
        }
    }

    free(nodes); free(open);
    free(closed); free(seen);
    return 0;
}
