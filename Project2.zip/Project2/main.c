#include "header.h"
#include "ga_config.h"
#include "ga.h"
#include "map.h"
#include "ipc.h"
#include "chromosome.h"


int main(void) {

  GA_Config cfg;      // <-- declare configuration struct
  Map3D *map = NULL;  // <-- declare map pointer

  init_config(&cfg);
    map = map_create(cfg.grid_x, cfg.grid_y, cfg.grid_z);
    if (!map) {
        fprintf(stderr, "Failed to create map (%d, %d, %d)\n",
                cfg.grid_x, cfg.grid_y, cfg.grid_z);
        return 1;
    }
    srand((unsigned)time(NULL)); 

    map_generate_pyramid(map,
			 cfg.grid_z,   // max_height
			 0.10,         // rubble_noise_prob
			 0.05);        // survivor_prob

printf("[MAIN] survivors generated = %d\n", map->survivor_count);
  
   Chromosome *pop = malloc(sizeof(Chromosome) * cfg.POP_SIZE);
   if (!pop) {
     fprintf(stderr, "Failed to allocate population\n");
     map_free(map);
     return 1;
   }
   for (int i = 0; i < cfg.POP_SIZE; i++) {
    if (!chromosome_alloc(&pop[i], cfg.num_robots)) {
        fprintf(stderr, "Failed to allocate chromosome %d\n", i);
        // free previous
        for (int j = 0; j < i; j++) chromosome_free(&pop[j]);
        free(pop);
        map_free(map);
        return 1;
    }
}

   init_population(map, &cfg, pop);
printf("[MAIN] num_workers before ipc_init = %d\n", cfg.num_workers);
  
   ipc_init(map, &cfg);
   printf("[MAIN] num_workers after ipc_init = %d\n", cfg.num_workers);
   run_ga(map, &cfg, pop);
   ipc_shutdown();

    for (int i = 0; i < cfg.POP_SIZE; i++)
      chromosome_free(&pop[i]);
   free(pop);
   
    return 0;
}
