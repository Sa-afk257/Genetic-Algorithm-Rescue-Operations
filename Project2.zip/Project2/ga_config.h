#ifndef GA_CONFIG_H
#define GA_CONFIG_H

typedef struct{

  int grid_x;
  int grid_y ;
  int grid_z;

  int POP_SIZE;
  int num_workers;
  int max_generations;
  int num_robots;

  double w_survivors;
  double w_coverage;
  double w_length;
  double w_risk;
  double w_collision;
  
  double MUTATION_RATE;
  double CROSSOVER_RATE;

  double ELITISM_RATE;
  int TOURNAMENT_K;

  int stagnation_limit;    // stop after N gens without improvement
  double stagnation_eps;   // improvement threshold
  int time_limit_sec;      // stop after N seconds (0 = disabled)
} GA_Config;

 void SetDefaultConfig(GA_Config *cfg);
 int loadConfigFile(const char *filename, GA_Config *cfg);
void init_config(GA_Config *cfg);


#endif
