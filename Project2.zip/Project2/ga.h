#ifndef GA_H
#define GA_H

#include "chromosome.h"
#include "map.h"        // for Map3D
#include "ga_config.h"  // GA_Config definition

/* ===========================
   Selection & Sorting
   =========================== */
int tournament_selection(Chromosome pop[], int pop_size, int k);
int compare_chromosomes(const void *a, const void *b);

/* ===========================
   Evolution Step
   =========================== */
void produce_next_generation(Map3D *m,
                             Chromosome pop[],
                             Chromosome new_pop[],
                             GA_Config *cfg);


/* ===========================
   Main GA Execution
   =========================== */
int rnd(int n);

void init_population(Map3D *map, GA_Config *cfg, Chromosome pop[]);

void run_ga(Map3D *m, GA_Config *cfg, Chromosome pop[]);

void init_moves26(void);
Vec3i map_get_random_survivor_or_free(Map3D *map);
Vec3i step_toward(Vec3i from, Vec3i to);
 void repair_one_path(Vec3i *nodes, int *len, Map3D *m);
void repair_path(Chromosome *c, Map3D *m);
void mutate(Chromosome *c, Map3D *m);
void chromosome_copy_into(Chromosome *dst, const Chromosome *src);
void crossover_into(Chromosome *dst, const Chromosome *p1, const Chromosome *p2, Map3D *m);
void print_best_path(const Chromosome *c);
void print_path_with_survivors(const Map3D *m, const Chromosome *c);
int is_neighbor26(Vec3i a, Vec3i b);

#endif
